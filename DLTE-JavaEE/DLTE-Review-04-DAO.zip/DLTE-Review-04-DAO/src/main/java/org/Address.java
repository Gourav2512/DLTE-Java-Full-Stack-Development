package org;

import lombok.Data;

@Data
public class Address {
    private int add_id;
    private String door_no;
    private String street;
    private String city;
    private int pincode;
    private  String type;

    public Address(int add_id,String door_no, String street, String city, int pincode, String type) {
        this.add_id = add_id;
        this.door_no = door_no;
        this.street = street;
        this.city = city;
        this.pincode = pincode;
        this.type = type;
    }

    public Address() {
    }
}
