package interfaces;

import org.Student;

import java.util.List;

public interface Operations {
    void insertDB(Student student);
    void deleteDB(int reg_no);
    List<Student> fetch();
}
